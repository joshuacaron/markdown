
    Polymer('markdown-editor', {
      markdown:"",
    });
