
    Polymer('markdown-editor', {
      markdown:"",
    });
